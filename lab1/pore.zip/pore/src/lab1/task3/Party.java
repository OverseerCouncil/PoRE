package lab1.task3;

import java.util.Arrays;

public class Party {

    // TODO: How to calculate the sequence of students?

    public int[] outputrank(int[] originalrank,int interval) {
        int[] result=new int[originalrank.length];
        Arrays.fill(result,0);
        return result;
    }

}
