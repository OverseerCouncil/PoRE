package lab1.task0;

// TODO: How to change the following codes to a runnable one?

int main(int argc, char *argv[]){
    printf("Hello World\n");
    return 0;
}


