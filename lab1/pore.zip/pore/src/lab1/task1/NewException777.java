package lab1.task1;

public class NewException777 extends Exception{
    // Do not change this method!
    public NewException777(String message){
            super("This in an new exception " + message);
        }
}
