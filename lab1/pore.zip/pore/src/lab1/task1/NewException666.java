package lab1.task1;

public class NewException666 extends Exception{
    // Do not change this method!
    public NewException666(String message){
        super("This in an new exception " + message);
    }
}
