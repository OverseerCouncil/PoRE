package lab1.task2;

public class GPA {
    public double myGPA=0;

    // TODO: How to make my gpa stable?

    public void add(double i){
        myGPA+=i;
    }

}
