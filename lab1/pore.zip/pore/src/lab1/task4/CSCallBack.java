package lab1.task4;

public interface CSCallBack {
    // Do not change this method!
    public void OnClick();
}
