package lab1.task4;

public class Task4 {
    public static void main(String[] args) {
        // Do not change this method!
        PhoneSystem ps = new PhoneSystem();
        App app = new App(ps);
        app.click();
    }
}
